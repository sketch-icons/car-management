package gmc.projects.cars.models;

public enum FuelType {
	Petrol, Diesel, Electric
}
